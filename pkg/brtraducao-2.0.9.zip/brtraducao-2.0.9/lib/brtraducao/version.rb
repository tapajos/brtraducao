module BrTraducao
  module VERSION #:nodoc:
    
    
    

    STRING = "2.0.9"
  end
end

module BrTraducao
  module VERSION #:nodoc:
    
    
    

    STRING = "2.0.14"
  end
end

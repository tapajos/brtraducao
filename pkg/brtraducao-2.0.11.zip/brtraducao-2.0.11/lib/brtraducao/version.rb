module BrTraducao
  module VERSION #:nodoc:
    
    
    

    STRING = "2.0.11"
  end
end

module BrTraducao
  module VERSION #:nodoc:
    
    
    

    STRING = "2.0.10"
  end
end
